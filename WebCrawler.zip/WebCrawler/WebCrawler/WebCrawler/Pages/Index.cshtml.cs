﻿using HtmlAgilityPack;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace WebCrawler.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        [BindProperty]
        public string UrlInput { get; set; }

        public List<string> ImgUrls { get; set; }
            public Result result { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            //ImgUrls = await GetImagesAsync("https://medium.com/better-programming/the-best-programming-language-to-learn-in-2022-senior-engineer-at-google-explains-5abcbc5f6556");
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            result = await GetImagesAsync(UrlInput);
            return Page();
        }

        public async Task<Result> GetImagesAsync(string userUrlInput)
        {
            Result result = new Result();
            List<WordCounter> wordCounters = new List<WordCounter>();
            List<string> tempImgUrls = new List<string>();
            string url = userUrlInput;
            var httpClient = new HttpClient();
            var html = await httpClient.GetStringAsync(url);
            var htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);

            foreach (HtmlNode node in htmlDocument.DocumentNode.SelectNodes("//img"))
            {
                tempImgUrls.Add(node.GetAttributeValue("src", ""));
            }
            //////////////////////////////////////////////////
            String allWords = htmlDocument.DocumentNode.InnerText;
            String[] wordsArray = allWords.Split(' ', ',', '.', '!', '-');
            List<string> strList = new List<string>();
            foreach (String word in wordsArray)
            {
                //only add a word if it is not yet in the list
                if (!strList.Contains(word))
                {
                    strList.Add(word);
                }

            }
            ////////////////////////////////////////
            //String allWords = textBox1.Text;
            //String[] wordsArray = allWords.Split(' ', ',', '.', '!', '-');

           

            foreach (string w in wordsArray)
            {
                WordCounter foundWord = wordCounters.Find(x => x.word == w);
                if (foundWord == null)
                {
                    wordCounters.Add(new WordCounter(w, 1));
                }
                else
                {
                    foundWord.frequency++;
                }
            }
            wordCounters = wordCounters.Where(w => w.word != "").ToList();
            wordCounters = wordCounters.OrderByDescending(w => w.frequency).Take(10).ToList();
 

            foreach (WordCounter word in wordCounters)
            {
                String[] rowItem = new string[] { word.frequency.ToString("D5"), word.word };
                //listView1.Items.Add(new ListViewItem(rowItem));
            }
            //////////////////////////////////////////////////
            result.wordCounters = wordCounters;
            result.tempImgUrls = tempImgUrls;
            return result;
        }

    }
}
