﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCrawler
{

    public class WordCounter
    {
        public string word { get; set; }
        public int frequency { get; set; }

        
        public WordCounter(string word, int frequency)
        {
            this.word = word;
            this.frequency = frequency;
        }

    }
    public class Result
    {
        public List<string> tempImgUrls { get; set; }
        public List<WordCounter> wordCounters { get; set; }
    }

}
